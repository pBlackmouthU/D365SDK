﻿using System;
using System.Collections.Generic;
using System.Web.Services;

namespace Web.Asp
{
    public partial class CrearContacto : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

          

            
        }
    }
}